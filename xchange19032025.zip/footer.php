
  <footer class="footer text-center text-muted">
      All Rights Reserved by GlobalTech.al. Designed and Developed by
      <a href="#">GlobalTech.al</a>.
  </footer>

  </div>
       
       </div>     
   </body>
   
   </html>